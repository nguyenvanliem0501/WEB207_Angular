import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {


  title = 'demo_project';
  subTitle = 'Nguyen Van Liem';


//   student = {
//     name: 'Nguyen Van Liem',
//     age: 20,
//     phone: '0392202682',
//     email: 'nguyenvanliem0501@gmail.com',
//     img: 'https://znews-photo.zadn.vn/w660/Uploaded/mdf_eioxrd/2021_07_12/2.jpg'
//   };

  students = [
    {
        id: 1,
        name: 'Nguyen Van Liem 1',
        age: 20,
        phone: '0392202682',
        email: 'nguyenvanliem0501@gmail.com',
        img: 'https://znews-photo.zadn.vn/w660/Uploaded/mdf_eioxrd/2021_07_12/2.jpg'
    },
    {
        id: 2,
        name: 'Nguyen Van Liem 2',
        age: 20,
        phone: '0392202682',
        email: 'nguyenvanliem0501@gmail.com',
        img: 'https://znews-photo.zadn.vn/w660/Uploaded/mdf_eioxrd/2021_07_12/2.jpg'
    },
    {
        id: 3,
        name: 'Nguyen Van Liem 3',
        age: 20,
        phone: '0392202682',
        email: 'nguyenvanliem0501@gmail.com',
        img: 'https://znews-photo.zadn.vn/w660/Uploaded/mdf_eioxrd/2021_07_12/2.jpg'
    }
  ];

//   remove(id :number) {
//    this.students = this.students.filter(student => student.id !== id);
//   }


  user = [
      {
            id: 1,
            ten: 'Nguyễn Văn Liêm',
            weight: 20,
            height: '172cm',
            img: 'https://photo-cms-sggp.zadn.vn/w580/Uploaded/2022/dqmbbcvo/2021_10_07/cristianoronaldo_ccdk.jpg',

      },
      {
            id: 2,
            ten: 'Than Hoang Anh',
            weight: 40,
            height: '172cm',
            img: 'https://photo-cms-sggp.zadn.vn/w580/Uploaded/2022/dqmbbcvo/2021_10_07/cristianoronaldo_ccdk.jpg',

      },
      {
            id: 3,
            ten: 'Nguyen Tuan Nam',
            weight: 10,
            height: '172cm',
            img: 'https://photo-cms-sggp.zadn.vn/w580/Uploaded/2022/dqmbbcvo/2021_10_07/cristianoronaldo_ccdk.jpg',

      },
      {
            id: 4,
            ten: 'Dam Tuan Khang',
            weight: 60,
            height: '172cm',
            img: 'https://photo-cms-sggp.zadn.vn/w580/Uploaded/2022/dqmbbcvo/2021_10_07/cristianoronaldo_ccdk.jpg',

      },
      
  ]

  remove(id :number) {
      const users = this.user.filter(us => us.id == id)

        if(users[0].weight > 30) {
            this.user = this.user.filter(us => us.id !== id)
        } else {
            alert("không xóa cân nặng < 30  ")
        }
      
  }
   
}
